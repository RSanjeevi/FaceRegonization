# Face detection and recognition in Python using OpenCV

![facerec.png](facerec.png)

This is the code used in this [tutorial](https://negaex.com/blog/facerec-python.html) from 2014.

Tested in Python 2.7 and 3.6 using OpenCV3.2.
